var fs = global.nodemodule["fs"];
var path = global.nodemodule["path"];
var wait = global.nodemodule["wait-for-stuff"];
var streamBuffers = global.nodemodule["stream-buffers"];
var fetch = global.nodemodule["node-fetch"];
var waiton = global.nodemodule["wait-on"];
var merge = global.nodemodule["merge-images"];
var jimp = global.nodemodule["jimp"];

function onLoad(data) {

var onLoadText = "Loaded \"Memer\" by Kaysil (FuryCS Mod)";

data.log(onLoadText);

}

function ensureExists(path, mask) {
  if (typeof mask != 'number') {
    mask = 0o777;
  }
  try {
    fs.mkdirSync(path, {
      mode: mask,
      recursive: true
    });
    return undefined;
  } catch (ex) {
    return { err: ex };
  }
}

var rootpath = path.resolve(__dirname, "..", "Memer-data");
ensureExists(rootpath);
ensureExists(path.join(rootpath, "sounds"));
ensureExists(path.join(rootpath, "images"));
ensureExists(path.join(rootpath, "temp"));

var nameMapping = {
	"khabanh_oibanoi": path.join(rootpath, "sounds", "khabanh_oibanoi.mp3"),
	"huanrose_colamthimoicoan": path.join(rootpath, "sounds", "huanrose_colamthimoicoan.mp3"),
	"duckbatman_trietlycuocsong": path.join(rootpath, "sounds", "duckbatman_trietlycuocsong.mp3"),
	"duckbatman_oibanoi": path.join(rootpath, "sounds", "duckbatman_oibanoi.mp3"),
	"slap_template": path.join(rootpath, "images", "slap_template.jpg")
}

for (var n in nameMapping) {
	if (!fs.existsSync(nameMapping[n])) {
		fs.writeFileSync(nameMapping[n], global.fileMap[n]);
	}
}

var defaultConfig = {
     "sounds": [
          {
               "filepath": "khabanh_oibanoi",
               "message": "Sức đề kháng yếu à? Nghe lời tư vấn của bác sĩ Bảnh"
          },
          {
               "filepath": "huanrose_colamthimoicoan",
               "message": ""
          },
          {
               "filepath": "duckbatman_oibanoi",
               "message": ""
          },
          {
               "filepath": "duckbatman_trietlycuocsong",
               "message": ""
		  }
		]
};

if (!fs.existsSync(path.join(rootpath, "config.json"))) {
	fs.writeFileSync(path.join(rootpath, "config.json"), JSON.stringify(defaultConfig, null, 5));
	var config = defaultConfig;
} else {
	var config = JSON.parse(fs.readFileSync(path.join(rootpath, "config.json"), {
		encoding: "utf8"
	}));
}

	switch (args[0].toLowerCase()) {
		default:
		return { 
		};
			break;
		case 'sounds':
		case 'sound':
		case 's':
			try {
		var randomItem = config.sounds[Math.floor(Math.random() * config.sounds.length)];
		var randomSounds = fs.createReadStream(path.join(rootpath, "sounds", randomItem.filepath+".mp3"));
		return data.return({
			handler: `internal-raw`,
			data: {
				body: randomItem.message,
				attachment: randomSounds
			}
		})
	} catch (err) {
		data.log(err)
	}
		break;
			case "neko":
			case "n":
				var nekoType = "";
				args.shift();
				if (!args[0]) nekoType = "neko|neko"; 
				else if (args[0] === "hug") nekoType = "hug|url"; 
				else if (args[0] === "kiss") nekoType = "kiss|url";
				else if (args[0] === "neko") nekoType = "neko|url";
				else if (args[0] === "lizard") nekoType = "lizard|url";
				else if (args[0] === "pat") nekoType = "pat|url";
				else if (args[0] === "8ball") nekoType = "8ball|url";
				else if (args[0] === "femdom") nekoType = "femdom|url";
				else if (args[0] === "tickle") nekoType = "tickle|url";
				else if (args[0] === "classic") nekoType = "classic|url";
				else if (args[0] === "ngif") nekoType = "ngif|url";
				else if (args[0] === "erofeet") nekoType = "erofeet|url";
				else if (args[0] === "meow") nekoType = "meow|url";
				else if (args[0] === "erok") nekoType = "erok|url";
				else if (args[0] === "poke") nekoType = "poke|url";
				else if (args[0] === "les") nekoType = "les|url";
				else if (args[0] === "hololewd") nekoType = "hololewd|url";
				else if (args[0] === "lewdk") nekoType = "meow|url";
				else if (args[0] === "keta") nekoType = "keta|url";
				else if (args[0] === "feetg") nekoType = "feetg|url";
				else if (args[0] === "nsfw") nekoType = "nsfw|url";
				else if (args[0] === "eroyuri") nekoType = "eroyuri|url";
				else if (args[0] === "kuni") nekoType = "kuni|url";
				else if (args[0] === "tits") nekoType = "tits|url";
				else if (args[0] === "pussy2") nekoType = "pussy_jpg|url";
				else if (args[0] === "cum2") nekoType = "cum_jpg|url";
				else if (args[0] === "pussy") nekoType = "pussy|url";
				else if (args[0] === "lewdkemo") nekoType = "lewdkemo|url";
				else if (args[0] === "bj") nekoType = "bj|url";
				else if (args[0] === "woof") nekoType = "woof|url";
				else if (args[0] === "yuri") nekoType = "yuri|url";
				else if (args[0] === "trap") nekoType = "trap|url";
				else if (args[0] === "anal") nekoType = "anal|url";
				else if (args[0] === "baka") nekoType = "baka|url";
				else if (args[0] === "blowjob") nekoType = "blowjob|url";
				else if (args[0] === "holoero") nekoType = "holoero|url";
				else if (args[0] === "feed") nekoType = "feed|url";
				else if (args[0] === "gasm") nekoType = "gasm|url";
				else if (args[0] === "hentai") nekoType = "hentai|url";
				else if (args[0] === "futanari") nekoType = "futanari|url";
				else if (args[0] === "eroFeet") nekoType = "eroFeet|url";
				else if (args[0] === "solo") nekoType = "solo|url";
				else if (args[0] === "waifu") nekoType = "waifu|url";
				else if (args[0] === "pwankg") nekoType = "pwankg|url";
				else if (args[0] === "eron") nekoType = "eron|url";
				else if (args[0] === "erokemo") nekoType = "erokemo|url";
				else if (args[0] === "loli") nekoType = "loli|url";
				else if (args[0] === "cumsluts") nekoType = "cumsluts|url";
				else if (args[0] === "avatar") nekoType = "avatar|url";
				else if (args[0] === "girlSolo") nekoType = "girlSolo|url";
				else if (args[0] === "girlSoloGif") nekoType = "girlSoloGif|url";
				else if (args[0] === "kitsune") nekoType = "kitsune|url";
				else if (args[0] === "eroKemonomimi") nekoType = "eroKemonomimi|url";
				else if (args[0] === "eroNeko") nekoType = "eroNeko|url";
				else if (args[0] === "eroYuri") nekoType = "eroYuri|url";
				else if (args[0] === "cumArts") nekoType = "cumArts|url";
				else nekoType = "neko|neko";
				try {
					var fetchjson = await fetch("http://nekos.life/api/v2/img/" + nekoType.split("|")[0]);
					var json = await fetchjson.json();

					var fetchimage = await fetch(json[nekoType.split("|")[1]]);
					var buffer = await fetchimage.buffer();
							var imagesx = new streamBuffers.ReadableStreamBuffer({
									frequency: 10,
									chunkSize: 1024
								});
								imagesx.path = "image.png";
								imagesx.put(buffer);
								imagesx.stop();
		
								return {
									handler: "internal-raw",
									data: {
										body: ``,
										attachment: ([imagesx])
									},
									noDelay: true
								}
					} catch (err) {
					data.log(err)
				}
		break;
	}

function sO(object) {
    return Object.keys(object).length;
}

module.exports = {
    memeFunc: meme,
    onLoad
};
